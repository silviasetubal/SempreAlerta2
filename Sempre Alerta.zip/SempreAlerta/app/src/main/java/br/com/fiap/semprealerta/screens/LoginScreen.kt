package br.com.fiap.semprealerta.screens



import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.com.fiap.semprealerta.R

@Composable
fun LoginScreen(modifier: Modifier = Modifier, navController: NavController){

    var emailState = remember{
        mutableStateOf("")
            }
    var passState = remember{
        mutableStateOf("")
    }
    Surface(
        modifier = Modifier
            .fillMaxSize(),
        color = Color(0xFF0A1734)
    ) {
        Column (modifier = Modifier
            .padding(
                vertical = 32.dp,
                horizontal = 48.dp
            ),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Column {

                Text(
                    text = "SEMPRE ALERTA",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB43D0B)

                )
                Image(painter = painterResource(id = R.drawable.sirene),
                    contentDescription = "Logo do App",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 13.dp))

                Text(
                    text = "Já tem uma conta? Faça o login",
                    color = Color(0xFFFFFFFF)
                )
            }
            Column (
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = emailState.value,
                    onValueChange = {
                        emailState.value = it
                    },
                    label = {
                        Text(text = "E-mail", color = Color.White)
                    },
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth(),

                )
                OutlinedTextField(
                    value = passState.value,
                    onValueChange = {
                        passState.value = it
                    },
                    label = {
                        Text(text = "Password", color = Color.White)
                    },
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Button(
                onClick = {
                    navController.navigate("home")
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44E08))
            ) {
                Text(text = "Login")

            }
            Text(
                text = AnnotatedString.Builder("Não tem uma conta? Cadastre-se aqui").apply {
                    addStyle(
                        style = SpanStyle(
                            color = Color.White,
                            textDecoration = TextDecoration.Underline
                        ),
                        start = 0,
                        end = length
                    )
                }.toAnnotatedString(),
                modifier = Modifier
                    .padding(top = 16.dp)
                    .clickable {
                        navController.navigate("register")
                    }
            )
        }


    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun LoginScreenPreview() {
    //LoginScreen()
}